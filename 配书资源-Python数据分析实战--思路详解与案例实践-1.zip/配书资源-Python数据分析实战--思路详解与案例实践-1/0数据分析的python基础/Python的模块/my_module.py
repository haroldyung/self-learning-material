def calculate_sum(example_list):
    print('这是一个求和函数')
    print(f'列表中所有元素的和为：{sum(example_list)}')
    length = len(example_list)
    
def calculate_sqrt(mylist):
    print('这是一个将列表内各元素开方的函数')
    
    # 在自定义模块中还可以调用第三方模块
    import numpy as np
    for i in range(0, len(mylist)):
        mylist[i] = np.sqrt(mylist[i])
    print(f'元素开方后的新列表：{mylist}')

# 基础配置
# 基础库
import numpy as np
import pandas as pd

# 基础绘图库
import matplotlib.pyplot as plt
import seaborn as sns
# %matplotlib inline
# 各种细节配置如 文字大小，图例文字等杂项
large = 22; med = 16; small = 12
params = {'axes.titlesize': large,
          'legend.fontsize': med,
          'figure.figsize': (16, 10),
          'axes.labelsize': med,
          'axes.titlesize': med,
          'xtick.labelsize': med,
          'ytick.labelsize': med,
          'figure.titlesize': large}
plt.rcParams.update(params)
plt.style.use('seaborn-whitegrid')
sns.set_style("white")
plt.rc('font', **{'family': 'Microsoft YaHei, SimHei'})  # 设置中文字体的支持
# sns.set(font='SimHei')  # 解决Seaborn中文显示问题，但会自动添加背景灰色网格

plt.rcParams['axes.unicode_minus'] = False
# 解决保存图像是负号'-'显示为方块的问题

# 提高输出效率库
from IPython.core.interactiveshell import InteractiveShell # 实现 notebook 的多行输出
InteractiveShell.ast_node_interactivity = 'all' #默认为'last'
from IPython.display import Image # 插入图片包
# Image(filename="img/pythonl. png", width=400, height=400)

import math

# 统计学库
import scipy.stats as stats
from scipy.stats import norm  # 用于拟合正态分布曲线

# ------------------------ 大纲速览 -------------------------------
"""
分布图：
pairplot：矩阵图（双变量探索利器）
norm_comparision_plot: 正态曲线比较图（后期泊松分布再改）
treemap：树图（饼图 pie chart 升级版）

关系图：
heatmap：热力图快捷
"""

####################### 绘制正态曲线 #######################
def normal_curve(mu, sigma, figsize=(10,8), despine=True):   
    """ 传入 x，均值 """
    #正态分布的概率密度函数。可以理解成 x 是 mu（均值）和 sigma（标准差）的函数
    def normfun(x, mu=mu, sigma=sigma):
        pdf = np.exp(-((x - mu)**2)/(2*sigma**2)) / (sigma * np.sqrt(2*np.pi))
        return pdf

    plt.figure(figsize=figsize)
    # Python实现正态分布
    # 绘制正态分布概率密度函数
    x = np.linspace(mu - 3*sigma, mu + 3*sigma, 50)
    y_sig = normfun(x=x, mu=mu, sigma=sigma)
    plt.plot(x, y_sig, "r-", linewidth=2) # 波形曲线

    # 添加垂直分隔线
    plt.vlines(mu, 0, np.exp(-(mu - mu) ** 2 /(2* sigma **2))/(np.sqrt(2*np.pi)*sigma), colors = "c", linestyles = "dashed")
    plt.vlines(mu+sigma, 0, np.exp(-(mu+sigma - mu) ** 2 /(2* sigma **2))/(np.sqrt(2*np.pi)*sigma), colors = "k", linestyles = "dotted")
    plt.vlines(mu+2*sigma, 0, np.exp(-(mu+2*sigma - mu) ** 2 /(2* sigma **2))/(np.sqrt(2*np.pi)*sigma), colors = "k", linestyles = "dotted")
    plt.vlines(mu-sigma, 0, np.exp(-(mu-sigma - mu) ** 2 /(2* sigma **2))/(np.sqrt(2*np.pi)*sigma), colors = "k", linestyles = "dotted")
    plt.vlines(mu-2*sigma, 0, np.exp(-(mu-2*sigma - mu) ** 2 /(2* sigma **2))/(np.sqrt(2*np.pi)*sigma), colors = "k", linestyles = "dotted")

    # 添加坐标轴
    plt.xticks ([mu-2*sigma, mu-sigma, mu , mu+sigma, mu+2*sigma],
                ['μ-2σ', 'μ-σ', 'μ', 'μ+σ', 'μ+2σ'])
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.title('Normal Distribution: $\mu = %.2f, $sigma=%.2f'%(mu,sigma))
    plt.grid(True)
    
    if despine == True:
        sns.despine(trim=True, left=True, offset=10)

######################## 分布图 #############################
# 关系堆叠图
def stack2dim(raw, i, j, rotation=0, location='best'):
    '''
    此函数是为了画两个维度标准化的堆积柱状图
    raw为pandas的DataFrame数据框
    i、j为两个分类变量的变量名称，要求带引号，比如"school"
    rotation：水平标签旋转角度，默认水平方向，如标签过长，可设置一定角度，比如设置rotation = 40
    location：分类标签的位置，如果被主体图形挡住，可更改为'upper left'
    '''
    import matplotlib.pyplot as plt
    import pandas as pd
    import numpy as np
    import math

    data_raw = pd.crosstab(raw[i], raw[j])
    data = data_raw.div(data_raw.sum(1), axis=0)  # 交叉表转换成比率，为得到标准化堆积柱状图

    # 计算x坐标，及bar宽度
    createVar = locals()
    x = [0]  # 每个bar的中心x轴坐标
    width = []  # bar的宽度
    k = 0
    for n in range(len(data)):
        # 根据频数计算每一列bar的宽度
        createVar['width' + str(n)] = list(data_raw.sum(axis=1))[n] / sum(data_raw.sum(axis=1))
        width.append(createVar['width' + str(n)])
        if n == 0:
            continue
        else:
            k += createVar['width' + str(n - 1)] / 2 + createVar['width' + str(n)] / 2 + 0.05
            x.append(k)

    # 以下是通过频率交叉表矩阵生成一串对应堆积图每一块位置数据的数组，再把数组转化为矩阵
    y_mat = []
    n = 0
    y_level = len(data.columns)
    for p in range(data.shape[0]):
        for q in range(data.shape[1]):
            n += 1
            y_mat.append(data.iloc[p, q])
            if n == data.shape[0] * data.shape[1]:
                break
            elif n % y_level != 0:
                y_mat.extend([0] * (len(data) - 1))
            elif n % y_level == 0:
                y_mat.extend([0] * len(data))

    y_mat = np.array(y_mat).reshape(-1, len(data))
    y_mat = pd.DataFrame(y_mat)  # bar图中的y变量矩阵，每一行是一个y变量

    # 通过x，y_mat中的每一行y，依次绘制每一块堆积图中的每一块图

    from matplotlib import cm
    cm_subsection = [level for level in range(y_level)]
    colors = [cm.Pastel1(color) for color in cm_subsection]

    bottom = [0] * y_mat.shape[1]
    createVar = locals()
    for row in range(len(y_mat)):
        createVar['a' + str(row)] = y_mat.iloc[row, :]
        color = colors[row % y_level]

        if row % y_level == 0:
            bottom = bottom = [0] * y_mat.shape[1]
            if math.floor(row / y_level) == 0:
                label = data.columns.name + ': ' + str(data.columns[row])
                plt.bar(x, createVar['a' + str(row)],
                        width=width[math.floor(row / y_level)], label=label, color=color)
            else:
                plt.bar(x, createVar['a' + str(row)],
                        width=width[math.floor(row / y_level)], color=color)
        else:
            if math.floor(row / y_level) == 0:
                label = data.columns.name + ': ' + str(data.columns[row])
                plt.bar(x, createVar['a' + str(row)], bottom=bottom,
                        width=width[math.floor(row / y_level)], label=label, color=color)
            else:
                plt.bar(x, createVar['a' + str(row)], bottom=bottom,
                        width=width[math.floor(row / y_level)], color=color)

        bottom += createVar['a' + str(row)]

    plt.title(j + ' vs ' + i)
    group_labels = [str(name) for name in data.index]
    plt.xticks(x, group_labels, rotation=rotation)
    plt.ylabel(j)
    plt.legend(shadow=True, loc=location)
    plt.show()

# 正态曲线比较分布图
def norm_comparision_plot(data, figsize=(12, 10), color="#099DD9",
                          ax=None, surround=True, grid=True):
    """
    function: 传入 DataFrame 指定行，绘制其概率分布曲线与正态分布曲线(比较)
    color: 默认为标准天蓝  #F79420:浅橙  ‘green’：直接绿色(透明度自动匹配)
    ggplot 经典三原色：'#F77B72'：浅红, '#7885CB'：浅紫, '#4CB5AB'：浅绿
    ax=None: 默认无需绘制子图的效果；  surround：sns.despine 的经典组合，
                                         默认开启，需要显式关闭
    grid：是否添加网格线，默认开启，需显式关闭                             
    """
    plt.figure(figsize=figsize) # 设置图片大小
    # fit=norm: 同等条件下的正态曲线(默认黑色线)；lw-line width 线宽
    sns.distplot(data, fit=norm, color=color, \
                 kde_kws={"color" :color, "lw" :3 }, ax=ax)
    (mu, sigma) = norm.fit(data)  # 求同等条件下正态分布的 mu 和 sigma
    # 添加图例：使用格式化输入，loc='best' 表示自动将图例放到最合适的位置
    plt.legend(['Normal dist. ($\mu=$ {:.2f} and $\sigma=$ {:.2f} )'. \
               format(mu, sigma)] ,loc='best')
    plt.ylabel('Frequency')
    plt.title("Distribution")
    if surround == True:
        # trim=True-隐藏上面跟右边的边框线，left=True-隐藏左边的边框线
        # offset：偏移量，x 轴向下偏移，更加美观
        sns.despine(trim=True, left=True, offset=10)
    if grid == True:
        plt.grid(True)  # 添加网格线


####################### 关系图 #############################
# 热力图 
def heatmap(data, method='pearson', camp='RdYlGn', figsize=(10 ,8), ax=None):
    """
    data: 整份数据
    method：默认为 pearson 系数
    camp：默认为：RdYlGn-红黄蓝；YlGnBu-黄绿蓝；Blues/Greens 也是不错的选择
    figsize: 默认为 10，8
    """
    ## 消除斜对角颜色重复的色块
    #     mask = np.zeros_like(df2.corr())
    #     mask[np.tril_indices_from(mask)] = True
    plt.figure(figsize=figsize, dpi= 80)
    sns.heatmap(data.corr(method=method), \
                xticklabels=data.corr(method=method).columns, \
                yticklabels=data.corr(method=method).columns, cmap=camp, \
                center=0, annot=True, ax=ax)
    # 要想实现只是留下对角线一半的效果，括号内的参数可以加上 mask=mask
    
# 树形图：饼图升级版
def treemap(data, column, figsize=(12 ,8), title=None, ax=None):
    """
    data: 整份数据
    column：传入格式 'col_name'
    基准行，求改行各定类变量的个数，并以占比的情况反映在矩形区域中
    """
    import squarify # 这个库需要 pip install 一下
    # Prepare Data
    # 下面这行代码是 pandas 中非常经典的操作，根据选中的名义变量进行分组，
        ## 分组后求每组的元素数量，并重置索引，新增的索引列为 counts，可以自己定制
        ## 这一行代码可以单独抽出来尝试使用并理解
    data = data.groupby(column).size().reset_index(name='counts')
    # 下面的这三行代码不用理解，就是在创造 squarify 时大神自己定义的
    labels = data.apply(lambda x: str(x[0]) + "\n (" + str(x[1]) + ")", axis=1)
    sizes = data['counts'].values.tolist() # 转成列表
    colors = [plt.cm.Spectral( i /float(len(labels))) for i in range(len(labels))]

    # Draw Plot
    plt.figure(figsize=figsize, dpi= 80) # 设置图片大小
    # 添加标签，图中部分元素
    squarify.plot(sizes=sizes, label=labels, color=colors, alpha=.8, ax=ax)

    # Decorate
    plt.title(title)
    plt.axis('off') # 关闭坐标轴显示
    plt.title(title)
    plt.show()
    
########################### 杂图 ##################################
def wordcloud_create(content, most_common_num=None,
                     figsize=(12,10), shape=None, 
                     background_color='white'):
    """ 
    函数功能：根据次词频生成词云，可自定义词云的背景颜色与轮廓
    content: 文本内容
    most_common_num: 最常出现的字的个数
    figsize: 默认大小为 12，10，彰显大气
    mask: 遮罩层，也称为词云图的轮廓，默认没有，需要自己添加
    background_color: 词云图背景颜色，默认白色
    """
    # ------------------ 引入必要库 --------------
    import jieba
    from PIL import Image
    from wordcloud import WordCloud  # 用来生成词云的库
    import matplotlib.pyplot as plt   # Python画图库
    from imageio import imread    
    # Python读取各类图像的库，imageio 好些，以前的一些其他的用不了了
    from collections import Counter   # Counter:计算器，计数员，用来统计词频
    # ------------------ 拼接文本 -------------------
    mylist = list(content)  # 用list()函数将导入的文件变成列表模式
    new_list = [" ".join(jieba.cut(sentence)) for sentence in mylist]
    # 逐一从my_list列表中抽出句子来给jieba这家伙截词，截了以后用join，以空格作为间隔连接起来
    # 不用逗号连接起来的原因，避免不必要的干扰
    con_words = ' '.join(new_list) # 这一行也很关键，消除换行符的影响
    frequencies = Counter(con_words).most_common(most_common_num)
    frequencies = dict(frequencies)
    # -----------设置词云轮廓并生成词云 --------------------
    if shape == None:
        wc = WordCloud(font_path='simhei.ttf',  # simhei.ttf:黑体
                        background_color=background_color,
                       max_words=2000
                      ).fit_words(frequencies)
        # 如：允许显示出来的最大词数，最大最大频率词的大小，等等
        plt.figure(figsize=figsize)
        plt.imshow(wc)
        plt.axis('off')  
        # axis: 轴，off掉，不显示坐标轴，否则会显示出以图片频率为xy轴的坐标轴
        plt.show()
    else:
        pac_mask = imread(shape)
        wc = WordCloud(font_path='simhei.ttf',  # simhei.ttf:黑体
                        background_color=background_color, 
                       max_words=2000,
                       mask=pac_mask).fit_words(frequencies)

        # 如：允许显示出来的最大词数，最大最大频率词的大小，等等
        plt.figure(figsize=figsize)
        plt.imshow(wc)
        plt.axis('off')  
        # axis: 轴，off掉，不显示坐标轴，否则会显示出以图片频率为xy轴的坐标轴


